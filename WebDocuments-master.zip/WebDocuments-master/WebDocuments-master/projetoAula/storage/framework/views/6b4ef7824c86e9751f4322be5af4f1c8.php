

<?php $__env->startSection('cadastroProduto'); ?>
    <h1>Cadastrar Novo Produto</h1>
    <form action="<?php echo e(route('produtos.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="nome">Nome:</label>
        <input type="text" name="nome" required>
        <label for="descricao">Descrição:</label>
        <textarea name="descricao" required></textarea>
        <label for="quantidade_estoque">Quantidade em Estoque:</label>
        <input type="number" name="quantidade_estoque" required>
        <label for="valor">Valor:</label>
        <input type="text" name="valor" required>
        <label for="categoria">Categoria:</label>
        <input type="text" name="categoria" required>
        <label for="estado_origem">Estado de Origem:</label>
        <select name="estado_origem" required>
            <option value="estado1">Estado 1</option>
            <option value="estado2">Estado 2</option>
        </select>
        <button type="submit">Salvar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebDocuments-master\projetoAula\resources\views/produtos/cadastroProduto.blade.php ENDPATH**/ ?>