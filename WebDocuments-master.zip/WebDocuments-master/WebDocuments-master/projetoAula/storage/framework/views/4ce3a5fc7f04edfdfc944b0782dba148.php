

<?php $__env->startSection('produtos'); ?>
    <h1>Lista de Produtos</h1>
    <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Quantidade em Estoque</th>
                <th>Valor</th>
                <th>Categoria</th>
                <th>Estado de Origem</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($produto->nome); ?></td>
                    <td><?php echo e($produto->descricao); ?></td>
                    <td><?php echo e($produto->quantidade_estoque); ?></td>
                    <td><?php echo e($produto->valor); ?></td>
                    <td><?php echo e($produto->categoria); ?></td>
                    <td><?php echo e($produto->estado_origem); ?></td>
                    <td>
                        <a href="<?php echo e(route('produtos.edit', $produto->id)); ?>">Editar</a>
                        <form action="<?php echo e(route('produtos.destroy', $produto->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Excluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <a href="<?php echo e(route('produtos.create')); ?>">Novo Produto</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebDocuments-master\projetoAula\resources\views/produtos/index.blade.php ENDPATH**/ ?>