<?php $__env->startSection('cadastro'); ?>
<h1>Cadastro de Usuário</h1>
<form action="<?php echo e(route('usuarios.novo')); ?>" method="post"> 
    <?php echo csrf_field(); ?> 
    <input type="text" name="nome" placeholder="Nome">
    <input type="text" name="login" placeholder="Login">
    <input type="text" name="senha" placeholder="Senha">
    <input type="submit" value="Enviar">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebDocuments-master\projetoAula\resources\views/usuarios/cadastro.blade.php ENDPATH**/ ?>